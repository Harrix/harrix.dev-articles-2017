#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <boost/math/special_functions/prime.hpp>
#include <boost/date_time/gregorian/gregorian.hpp>

using namespace boost::math;
using namespace boost::gregorian;

MainWindow::MainWindow(QWidget *parent)
  : QMainWindow(parent)
  , ui(new Ui::MainWindow)
{
  ui->setupUi(this);
}

MainWindow::~MainWindow()
{
  delete ui;
}


void MainWindow::on_pushButton_clicked()
{
  // Седьмое простое число
  boost::uint32_t k = prime(7);
  ui->textEdit->insertPlainText(QString::number(k) + "\n");

  // Сколько дней прошло с 1 января
  date today = day_clock::local_day();
  partial_date new_years_day(1,Jan);
  days days_since_year_start = today - new_years_day.get_date(today.year());
  ui->textEdit->insertPlainText(QString::number(days_since_year_start.days()) + "\n");
}
